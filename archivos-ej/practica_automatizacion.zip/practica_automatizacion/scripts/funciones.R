##Functions to perform Grinnellian niche Overlao and Niche Similarity Test
#Author: Gerardo Dirzo Uribe

####do_pca####
#' do_pca function uses the climatic data extracted from Accessibility Areas (or Backgrounds) to perform a Principal Component Analysis (PCA).
#'
#' @param bkgclim.sp1 A data frame object with the background climates extracted for species 1, the data frame must be include two columns of lat and lon, a column fill in with the species name, and whole columns of climate variables.
#' @param bkgclim.sp2 A data frame object with the background climates extracted for species 2, the data frame must be include two columns of lat and lon, a column fill in with the species name, and whole columns of climate variables.
#'
#' @return a list with the species' names used in the analysis, a data frame of the combined background points of both species (with repeated points deleted), and the PCA calculated.

do_pca <- function(bkgclim.sp1, bkgclim.sp2){
  
  resultsPca <- list()
  
  namesp1 <- unique(bkgclim.sp1$sp)
  namesp2 <- unique(bkgclim.sp2$sp)
  
  dataComb <- bind_rows(bkgclim.sp1, bkgclim.sp2) %>%
    dplyr::distinct(lon, lat, .keep_all = TRUE) %>% 
    na.omit()
  
  PB <- dataComb %>% 
    dplyr::select(lon, lat, sp)
  
  CC <- dataComb %>% 
    dplyr::select(!c(lon, lat, sp))
  
  PCA <- ade4::dudi.pca(CC, center=TRUE,scale=TRUE,scannf=FALSE,nf=2)
  
  resultsPca[[1]] <- namesp1
  resultsPca[[2]] <- namesp2
  resultsPca[[3]] <- PB
  resultsPca[[4]] <- PCA
  
  resultsPca <- list(sp1=namesp1, sp2=namesp2, bkg.points=PB, PCA=PCA)
  return(resultsPca)
}
#

####get_scores####
#' get_scores function uses the list object (obtained from the do_pca function) to extracts scores from the combined background and from the individual occurrences of each species.
#'
#' @param sp1.clim A file with the climates extracted for species 1 occurrences (columns 'lat', 'lon', 'sp' (fill in with species name) and climates variables)
#' @param sp2.clim A file with the climates extracted for species 2 occurrences (columns 'lat', 'lon', 'sp' (fill in with species name) and climates variables)
#' @param bkgclim.sp1 A file with the climates extracted for species 1 background (columns 'lat', 'lon', 'sp' (fill in with species name) and climates variables)
#' @param bkgclim.sp2 A file with the climates extracted for species 2 background (columns 'lat', 'lon', 'sp' (fill in with species name) and climates variables)
#' @param p.comp A list class object resulting from the do_pca function
#'
#' @return a list that containing background scores, and both species scores.
get_scores <- function(sp1.clim, sp2.clim, bkgclim.sp1, bkgclim.sp2, p.comp) {
  
  listGetScores <- list()
  
  nameSp1 <- unique(sp1.clim$sp)
  nameSp2 <- unique(sp2.clim$sp)
  
  scrMs <- cbind(p.comp$bkg.points, p.comp$PCA$li) %>% 
    dplyr::mutate(pc1=Axis1, pc2=Axis2) %>% 
    dplyr::select(sp, lon, lat, pc1, pc2)
  
  B1<- bkgclim.sp1 %>% 
    dplyr::select(!c(lat, lon, sp))
  BS1 <- ade4::suprow(p.comp$PCA, B1)$lisup
  scrbkg1 <- cbind(bkgclim.sp1, BS1) %>% 
    dplyr::mutate(pc1=Axis1, pc2=Axis2) %>%
    dplyr::select(sp, lon, lat, pc1, pc2) %>% 
    na.omit()
  
  B2<- bkgclim.sp2 %>% 
    dplyr::select(!c(lat, lon, sp))
  BS2 <- ade4::suprow(p.comp$PCA, B2)$lisup
  scrbkg2 <- cbind(bkgclim.sp2, BS2) %>% 
    dplyr::mutate(pc1=Axis1, pc2=Axis2) %>%
    dplyr::select(sp, lon, lat, pc1, pc2) %>% 
    na.omit()
  
  C1<- sp1.clim %>% 
    dplyr::select(!c(lat, lon, sp))
  S1 <- suprow(p.comp$PCA, C1)$lisup
  scrSp1 <- cbind(sp1.clim, S1) %>% 
    dplyr::mutate(pc1=Axis1, pc2=Axis2) %>%
    dplyr::select(sp, lon, lat, pc1, pc2) %>% 
    na.omit()
  
  C2<- sp2.clim %>% 
    dplyr::select(!c(lat, lon, sp))
  S2 <- suprow(p.comp$PCA, C2)$lisup
  scrSp2 <- cbind(sp2.clim, S2) %>% 
    dplyr::mutate(pc1=Axis1, pc2=Axis2) %>%
    dplyr::select(sp, lon, lat, pc1, pc2) %>% 
    na.omit()
  
  listGetScores[[1]]<-nameSp1
  listGetScores[[2]]<-nameSp2
  listGetScores[[3]]<-scrMs
  listGetScores[[4]]<-scrSp1
  listGetScores[[5]]<-scrSp2
  listGetScores[[6]]<-scrbkg1
  listGetScores[[7]]<-scrbkg2
  
  listGetScores <- list(sp1=nameSp1, sp2=nameSp2, bkgScores=scrMs, sp1Scores=scrSp1, sp2Scores=scrSp2, bkg1Scores=scrbkg1, bkg2Scores=scrbkg2)
  
  return(listGetScores)
}
#

####NicheOv_SimTest####
#' NicheOv_SimTest function estimates the kernel densities (z's), the Grinnellian Niche Overlap, and performs the Niche Similarity Test. It starts with a list resulting from get_scores function.
#'
#' @param all.scores A list class object resulting from get_scores function.
#' #' @param sim.test Logical argument, if TRUE, performs the niche similarity test. FALSE returns only Shoner's D Overlap. Default TRUE
#' @param save.z Logical argument, if TRUE, returns both kernel densities (sp 1 and sp 2). Default FALSE
#'
#' @return a list that contains the names of the evaluated species pair, kernel densities (for both species), Shoener's D (Grinnellian Niche Overlap), and both p values (sp1 vs sp2 and sp2 vs sp1) of similarity test.
NicheOv_SimTest <- function(all.scores, sim.test=TRUE, save.z=FALSE) {
  
  scrMs <- all.scores$bkgScores %>% 
    dplyr::select(pc1, pc2) 
  scrSp1 <- all.scores$sp1Scores %>% 
    dplyr::select(pc1, pc2)
  scrSp2 <- all.scores$sp2Scores %>% 
    dplyr::select(pc1, pc2)
  bkg1Scores <- all.scores$bkg1Scores %>% 
    dplyr::select(pc1, pc2)
  bkg2Scores <- all.scores$bkg2Scores %>% 
    dplyr::select(pc1, pc2)
  
  nameSp1 <- unique(all.scores$sp1Scores$sp)
  nameSp2 <- unique(all.scores$sp2Scores$sp)
  
  zeta1<-ecospat::ecospat.grid.clim.dyn(scrMs,bkg1Scores,scrSp1,R=100)
  zeta2<-ecospat::ecospat.grid.clim.dyn(scrMs,bkg2Scores,scrSp2,R=100)
  
  if(sim.test==TRUE){
    
    NST1 <- ecospat::ecospat.niche.similarity.test(zeta1, zeta2, rep=100, ncores = 4)
    pD1 <- NST1$p.D
    
    NST2 <- ecospat::ecospat.niche.similarity.test(zeta2, zeta1, rep=100, ncores = 4)
    pD2 <- NST2$p.D
    
    NO <- NST1$obs$D
    
    resultAllScrs <- list()
    resultAllScrs[[1]] <- nameSp1
    resultAllScrs[[2]] <- nameSp2
    resultAllScrs[[3]] <- NO
    resultAllScrs[[4]] <- pD1
    resultAllScrs[[5]] <- pD2
    resultAllScrs <- list(Sp1=nameSp1, Sp2=nameSp2, D=NO, pD.Sp1.Sp2=pD1, pD.Sp2.Sp1=pD2)
    if(save.z=="TRUE") {
      resultAllScrs[[6]] <- zeta1
      resultAllScrs[[7]] <- zeta2
      resultAllScrs <- list(Sp1=nameSp1, Sp2=nameSp2, D=NO, pD.Sp1.Sp2=pD1, pD.Sp2.Sp1=pD2, z.Sp1=zeta1, z.Sp2=zeta2)
    } 
    
  } else{
    
    NicheOv <- ecospat::ecospat.niche.overlap(zeta1, zeta2, cor=TRUE)
    
    NO <- NicheOv$D
    
    resultAllScrs <- list()
    resultAllScrs[[1]] <- nameSp1
    resultAllScrs[[2]] <- nameSp2
    resultAllScrs[[3]] <- NO
    resultAllScrs <- list(Sp1=nameSp1, Sp2=nameSp2, D=NO)
    if(save.z=="TRUE") {
      resultAllScrs[[4]] <- zeta1
      resultAllScrs[[5]] <- zeta2
      resultAllScrs <- list(Sp1=nameSp1, Sp2=nameSp2, D=NO,z.Sp1=zeta1, z.Sp2=zeta2)
    } 
    
  }

  return(resultAllScrs)
}
#